<?php
require 'Slim/Slim.php';
\Slim\Slim::registerAutoloader();
$app = new \Slim\Slim();
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'sisdis';
$env = 'localhost/sisdis/tugas1/';

$conn = mysqli_connect($servername, $username, $password, $dbname);
if (!$conn) {
  die("Connection failed: " . mysqli_connect_error());
}

// API group
$app->group('/ewallet', function () use ($app, $conn) {

  $app->get('/ping', function () {
    ping();
  });

  $app->get('/getSaldo', function () use ($conn){
    $app = \Slim\Slim::getInstance();
    $user_id = $app->request->get('user_id');
    $output["nilai_saldo"] = getSaldo($conn, $user_id);
    $app->response()->headers->set('Content-Type', 'application/json');
    echo json_encode($output);
  });

  $app->post('/register', function () use ($conn) {
    $app = \Slim\Slim::getInstance();
    $json = json_decode($app->request->getBody());
    $sql = "INSERT INTO user (user_id, ip_domisili, nama)
    VALUES ('".$json->user_id."', '".$json->ip_domisili."', '".$json->nama."')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
  });

  $app->post('/requestTransfer', function () use ($conn){
    global $env;
    $app = \Slim\Slim::getInstance();
    $json = json_decode($app->request->getBody());
    $cabang_tujuan = $json->cabang_tujuan;
    $user_id = $json->user_id;
    $nilai = $json->nilai;

    $response = getSaldoCurl($env, $user_id);
    if($response == -1){
      $object['status_transfer'] = -1;
      $object['message'] = 'user tidak ditemukan di cabang ilham.';
      echo json_encode($object);
    }else {
      $saldo = $response;
      if ($saldo < $nilai) {
        $object['status_transfer'] = -1;
        $object['message'] = 'saldo tidak cukup.';
        echo json_encode($object);
      }else {
        // call transfer
        $object['user_id'] = $user_id;
        $object['nilai'] = $nilai;
        $ch = curl_init($cabang_tujuan."/transfer");
        curl_setopt_array($ch, array(
          CURLOPT_POST => TRUE,
          CURLOPT_RETURNTRANSFER => TRUE,
          CURLOPT_HTTPHEADER => array('Content-Type:application/json; charset=utf-8'),
          CURLOPT_POSTFIELDS => json_encode($object)
        ));
        $response = curl_exec($ch);
        $response = json_decode($response,true);
        if($response['status_transfer'] == 0){
          $saldo = getSaldoCurl($env, $user_id);
          $saldo = $saldo - $nilai;
          $sql = "UPDATE user SET saldo='$saldo' where user_id='$user_id'";
          $result = $conn->query($sql);
          if($result){
            $object['status_transfer'] = 0;
            $object['message'] = 'Transfer ke cabang tujuan ilham BERHASIL';
            echo json_encode($object);
          }else{
            $object['status_transfer'] = -1;
            $object['message'] = 'Transfer ke cabang tujuan ilham GAGAL';
            echo json_encode($object);
          }
        }
      }
    }
  });

  $app->post('/transfer', function () use ($conn) {
    global $env;
    $app = \Slim\Slim::getInstance();
    $json = json_decode($app->request->getBody());
    $user_id = $json->user_id;
    $nilai = $json->nilai;

    $response = getSaldoCurl($env, $user_id);
    if($response == -1){
      $object['status_transfer'] = -1;
      $object['message'] = 'user tidak ditemukan di cabang ilham.';
      echo json_encode($object);
    }else{
      // process transfer
      $saldo = $response + $nilai;
      $sql = "UPDATE user SET saldo='$saldo' where user_id='$user_id'";
      $result = $conn->query($sql);
      if($result){
        $object['status_transfer'] = 0;
        $object['message'] = 'Transfer ke cabang tujuan ilham BERHASIL';
        echo json_encode($object);
      }else{
        $object['status_transfer'] = -1;
        $object['message'] = 'Transfer ke cabang tujuan ilham GAGAL';
        echo json_encode($object);
      }
    }
  });
});

function ping(){
  $app = \Slim\Slim::getInstance();
  $output["pong"] = 1;
  $app->response()->headers->set('Content-Type', 'application/json');
  echo json_encode($output);
}

function getSaldoCurl($tujuan, $user_id){
  global $env;
  $url = $env."ewallet/getSaldo?user_id=".$user_id;
  $ch = curl_init();
  curl_setopt_array($ch, array(
    CURLOPT_SSL_VERIFYPEER => TRUE,
    CURLOPT_SSL_VERIFYHOST => 2,
    CURLOPT_RETURNTRANSFER => TRUE,
    CURLOPT_URL => $url
  ));
  $response = curl_exec($ch);
  $response = json_decode($response);
  return $response->nilai_saldo;
}

function getSaldo($conn, $user_id){
  $app = \Slim\Slim::getInstance();
  $sql = "SELECT saldo FROM user WHERE user_id = '".$user_id."'";
  $result = $conn->query($sql);
  $row = mysqli_fetch_row($result);
  if (count($row) > 0) {
    return $row[0];
  } else {
    return "-1";
  }
}

function quorum(){

}

$app->run();
